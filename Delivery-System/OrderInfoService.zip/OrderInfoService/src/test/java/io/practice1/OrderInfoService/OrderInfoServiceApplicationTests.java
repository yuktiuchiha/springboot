package io.practice1.OrderInfoService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderInfoServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
