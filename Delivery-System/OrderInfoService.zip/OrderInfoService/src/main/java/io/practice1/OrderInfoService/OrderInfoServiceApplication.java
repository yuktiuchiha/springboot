package io.practice1.OrderInfoService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderInfoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderInfoServiceApplication.class, args);
	}

}
